<?php
namespace Veldorname\Extkey\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2014
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * MdelTestController
 */
class MdelTestController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * mdelTestRepository
	 *
	 * @var \Veldorname\Extkey\Domain\Repository\MdelTestRepository
	 * @inject
	 */
	protected $mdelTestRepository = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
	
		$tsSettings = $this->configurationManager->getConfiguration(
					\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FRAMEWORK,
					'extkey',
					'extkey_pi1'
				);
				//echo var_dump($tsSettings['settings']);die;	//settings from setup.txt
				
		$originalSettings = $this->configurationManager->getConfiguration(
					\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_SETTINGS
				);
			$set = $this->settings;	//setting from setup.txt and flexform
	//echo var_dump($set);die;
		if($set['firstset']== '1'){
			echo "work";
		}
		else {echo "not work";}
			
		//die;
		
		$mdelTests = $this->mdelTestRepository->findAll();
		$this->view->assign('mdelTests', $mdelTests);
}

	/**
	 * action show
	 *
	 * @param \Veldorname\Extkey\Domain\Model\MdelTest $mdelTest
	 * @return void
	 */
	public function showAction(\Veldorname\Extkey\Domain\Model\MdelTest $mdelTest) {
		$this->view->assign('mdelTest', $mdelTest);
	}

	/**
	 * action new
	 *
	 * @param \Veldorname\Extkey\Domain\Model\MdelTest $newMdelTest
	 * @ignorevalidation $newMdelTest
	 * @return void
	 */
	public function newAction(\Veldorname\Extkey\Domain\Model\MdelTest $newMdelTest = NULL) {
		$this->view->assign('newMdelTest', $newMdelTest);
	}

	/**
	 * action create
	 *
	 * @param \Veldorname\Extkey\Domain\Model\MdelTest $newMdelTest
	 * @return void
	 */
	public function createAction(\Veldorname\Extkey\Domain\Model\MdelTest $newMdelTest) {
		$this->addFlashMessage('The object was created. Please be aware that this action is publicly accessible unless you implement an access check. See <a href="http://wiki.typo3.org/T3Doc/Extension_Builder/Using_the_Extension_Builder#1._Model_the_domain" target="_blank">Wiki</a>', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->mdelTestRepository->add($newMdelTest);
		$this->redirect('list');
	}

	/**
	 * action edit
	 *
	 * @param \Veldorname\Extkey\Domain\Model\MdelTest $mdelTest
	 * @ignorevalidation $mdelTest
	 * @return void
	 */
	public function editAction(\Veldorname\Extkey\Domain\Model\MdelTest $mdelTest) {
		$this->view->assign('mdelTest', $mdelTest);
	}

	/**
	 * action update
	 *
	 * @param \Veldorname\Extkey\Domain\Model\MdelTest $mdelTest
	 * @return void
	 */
	public function updateAction(\Veldorname\Extkey\Domain\Model\MdelTest $mdelTest) {
		$this->addFlashMessage('The object was updated. Please be aware that this action is publicly accessible unless you implement an access check. See <a href="http://wiki.typo3.org/T3Doc/Extension_Builder/Using_the_Extension_Builder#1._Model_the_domain" target="_blank">Wiki</a>', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->mdelTestRepository->update($mdelTest);
		$this->redirect('list');
	}

	/**
	 * action delete
	 *
	 * @param \Veldorname\Extkey\Domain\Model\MdelTest $mdelTest
	 * @return void
	 */
	public function deleteAction(\Veldorname\Extkey\Domain\Model\MdelTest $mdelTest) {
		$this->addFlashMessage('The object was deleted. Please be aware that this action is publicly accessible unless you implement an access check. See <a href="http://wiki.typo3.org/T3Doc/Extension_Builder/Using_the_Extension_Builder#1._Model_the_domain" target="_blank">Wiki</a>', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->mdelTestRepository->remove($mdelTest);
		$this->redirect('list');
	}

}
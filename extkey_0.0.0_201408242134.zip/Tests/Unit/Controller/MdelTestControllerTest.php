<?php
namespace Veldorname\Extkey\Tests\Unit\Controller;
/***************************************************************
 *  Copyright notice
 *
 *  (c) 2014 
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class Veldorname\Extkey\Controller\MdelTestController.
 *
 */
class MdelTestControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {

	/**
	 * @var \Veldorname\Extkey\Controller\MdelTestController
	 */
	protected $subject = NULL;

	protected function setUp() {
		$this->subject = $this->getMock('Veldorname\\Extkey\\Controller\\MdelTestController', array('redirect', 'forward', 'addFlashMessage'), array(), '', FALSE);
	}

	protected function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function listActionFetchesAllMdelTestsFromRepositoryAndAssignsThemToView() {

		$allMdelTests = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array(), array(), '', FALSE);

		$mdelTestRepository = $this->getMock('Veldorname\\Extkey\\Domain\\Repository\\MdelTestRepository', array('findAll'), array(), '', FALSE);
		$mdelTestRepository->expects($this->once())->method('findAll')->will($this->returnValue($allMdelTests));
		$this->inject($this->subject, 'mdelTestRepository', $mdelTestRepository);

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('mdelTests', $allMdelTests);
		$this->inject($this->subject, 'view', $view);

		$this->subject->listAction();
	}

	/**
	 * @test
	 */
	public function showActionAssignsTheGivenMdelTestToView() {
		$mdelTest = new \Veldorname\Extkey\Domain\Model\MdelTest();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$this->inject($this->subject, 'view', $view);
		$view->expects($this->once())->method('assign')->with('mdelTest', $mdelTest);

		$this->subject->showAction($mdelTest);
	}

	/**
	 * @test
	 */
	public function newActionAssignsTheGivenMdelTestToView() {
		$mdelTest = new \Veldorname\Extkey\Domain\Model\MdelTest();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('newMdelTest', $mdelTest);
		$this->inject($this->subject, 'view', $view);

		$this->subject->newAction($mdelTest);
	}

	/**
	 * @test
	 */
	public function createActionAddsTheGivenMdelTestToMdelTestRepository() {
		$mdelTest = new \Veldorname\Extkey\Domain\Model\MdelTest();

		$mdelTestRepository = $this->getMock('Veldorname\\Extkey\\Domain\\Repository\\MdelTestRepository', array('add'), array(), '', FALSE);
		$mdelTestRepository->expects($this->once())->method('add')->with($mdelTest);
		$this->inject($this->subject, 'mdelTestRepository', $mdelTestRepository);

		$this->subject->createAction($mdelTest);
	}

	/**
	 * @test
	 */
	public function editActionAssignsTheGivenMdelTestToView() {
		$mdelTest = new \Veldorname\Extkey\Domain\Model\MdelTest();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$this->inject($this->subject, 'view', $view);
		$view->expects($this->once())->method('assign')->with('mdelTest', $mdelTest);

		$this->subject->editAction($mdelTest);
	}

	/**
	 * @test
	 */
	public function updateActionUpdatesTheGivenMdelTestInMdelTestRepository() {
		$mdelTest = new \Veldorname\Extkey\Domain\Model\MdelTest();

		$mdelTestRepository = $this->getMock('Veldorname\\Extkey\\Domain\\Repository\\MdelTestRepository', array('update'), array(), '', FALSE);
		$mdelTestRepository->expects($this->once())->method('update')->with($mdelTest);
		$this->inject($this->subject, 'mdelTestRepository', $mdelTestRepository);

		$this->subject->updateAction($mdelTest);
	}

	/**
	 * @test
	 */
	public function deleteActionRemovesTheGivenMdelTestFromMdelTestRepository() {
		$mdelTest = new \Veldorname\Extkey\Domain\Model\MdelTest();

		$mdelTestRepository = $this->getMock('Veldorname\\Extkey\\Domain\\Repository\\MdelTestRepository', array('remove'), array(), '', FALSE);
		$mdelTestRepository->expects($this->once())->method('remove')->with($mdelTest);
		$this->inject($this->subject, 'mdelTestRepository', $mdelTestRepository);

		$this->subject->deleteAction($mdelTest);
	}
}

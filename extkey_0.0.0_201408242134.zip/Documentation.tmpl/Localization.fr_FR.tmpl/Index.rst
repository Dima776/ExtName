﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _start:

=============================================================
###PROJECT_NAME### (Français)
=============================================================

.. only:: html

	:Classification:
		extension_key

	:Version:
		|release|

	:Langue:
		fr

	:Description:
		entrez une description.

	:Mots-clés:
		list,mots-clés,séparés,par,virgules

	:Copyright:
		###YEAR###

	:Auteur:
		###AUTHOR###

	:E-mail:
		author@example.com

	:Licence:
		Ce document est publié sous la licence de contenu libre
		disponible sur http://www.opencontent.org/opl.shtml

	:Généré:
		|today|

	Le contenu de ce document est en relation avec TYPO3,
	un CMS/Framework GNU/GPL disponible sur `www.typo3.org <http://www.typo3.org/>`_.


	**Sommaire**

.. toctree::
	:maxdepth: 5
	:titlesonly:
	:glob:

..	Introduction/Index
..	UserManual/Index
..	AdministratorManual/Index
..	Configuration/Index
..	DeveloperCorner/Index
..	KnownProblems/Index
..	ToDoList/Index
..	ChangeLog/Index
